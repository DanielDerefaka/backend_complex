# complex Trading Backend 
## npm start to initialize the application 


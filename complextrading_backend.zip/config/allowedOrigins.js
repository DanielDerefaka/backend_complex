const allowdOrigins = [
    "http://localhost:5000",
      "http://localhost:3001",
      "http://localhost:5173",
]

module.exports = allowdOrigins